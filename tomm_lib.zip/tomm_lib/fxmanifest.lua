--[[----------------------------------
Author: 		Tomm
Creation Date:	18/01/2022
]]------------------------------------
fx_version 'adamant'
game 'gta5'
author 'Tomm'
version '1.0.0'
lua54 'yes'
client_scripts {
    'config.lua',
    'client.lua'
}

server_scripts {
    'config.lua',
    'server.lua',
}

escrow_ignore {
  'config.lua'
}