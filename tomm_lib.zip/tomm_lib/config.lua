TOMM = {}

TOMM.Framework = "ESX" -- "ESX" or "QBCore"

TOMM.NewESX = true -- TURE = export | false = TriggerEvent