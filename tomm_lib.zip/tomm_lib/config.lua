Config = {}

Config.Framework = "ESX" -- "ESX" or "QBCore"

Config.NewESX = true -- TURE = export | false = TriggerEvent